/**
 * PLSB Interactive Presentation Dashboard — Client Application
 * Modular 6-tab SPA: Analyzer, Buffer Visualization, Token Statistics, Markov Prediction, PLSB Comparison, About.
 * Retains renderReallocsChart and API hooks for complete endpoint and test compatibility.
 */

// Global State
const state = {
    currentSource: "",
    analysisResult: null,
    tokens: [],
    bufferSimulation: {
        bufferSize: 40,
        buffer1: "",
        buffer2: "",
        activeBuffer: 1,
        charPointer: 0,
        forwardPointer: 0,
        currentChar: "",
        currentLexeme: "",
        refillCount: 0,
        spillCount: 0,
        isSpilled: false,
        position: 0,
        isPlaying: false,
        timer: null
    },
    markovTransitions: [],
    markovSelectedToken: "",
    freqMode: "type", // "type" | "lexeme"
    freqChart: null,
    cmpReallocChart: null,
    cmpCopyChart: null,
    legacyChart: null
};

// Standard Example Programs
const EXAMPLES = {
    ex1: `#include <stdio.h>
#include <stdlib.h>

/* Structure declaration */
typedef struct {
    int id;
    double score;
    char name[64];
} record_t;

int main(int argc, char** argv) {
    record_t item;
    item.id = 101;
    item.score = 98.75;
    printf("Record initialized: %d\\n", item.id);
    return 0;
}`,
    ex2: `/* Boundary Stress: Extended Comments, Identifiers, and String Literals */
#include <stdio.h>

// Extended identifier designed to exceed small buffer boundaries
static const char* enterprise_database_connection_pool_session_identifier_key = "DB_KEY";

/* Long multi-line documentation comment designed to test boundary spill buffering across multiple refills:
 * Line 1: Compilers utilize fixed-size double buffers to scan continuous token streams.
 * Line 2: Long comments and string literals require auxiliary spill buffering.
 * Line 3: PLSB dynamically anticipates capacity needs to eliminate reallocation cascades.
 */
int test_buffer_spill_boundary_transition(void) {
    char payload_message[] = "EXTENDED_QUERY: SELECT user_id, session_token, auth_signature, access_level, registration_timestamp FROM secure_enterprise_accounts WHERE account_status = 'ACTIVE';";
    return 42;
}`
};

// Keywords and Lexer mapping
const C_KEYWORDS = new Set([
    "auto", "break", "case", "char", "const", "continue", "default", "do",
    "double", "else", "enum", "extern", "float", "for", "goto", "if",
    "int", "long", "register", "return", "short", "signed", "sizeof", "static",
    "struct", "switch", "typedef", "union", "unsigned", "void", "volatile", "while"
]);

// Initialization
document.addEventListener("DOMContentLoaded", () => {
    initTabs();
    initAnalyzer();
    initBufferSimulation();
    initTokenStats();
    initMarkov();
    initComparison();

    // Load Example 1 by default and analyze
    const editor = document.getElementById("sourceCodeInput");
    if (editor) {
        editor.value = EXAMPLES.ex1;
        state.currentSource = EXAMPLES.ex1;
        analyzeSourceCode(EXAMPLES.ex1);
    }
});

// =========================================================================
// TAB NAVIGATION
// =========================================================================
function initTabs() {
    const tabs = document.querySelectorAll(".nav-tab");
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");

            const targetTab = tab.dataset.tab;
            document.querySelectorAll(".tab-pane").forEach(pane => {
                pane.classList.remove("active");
            });

            const targetPane = document.getElementById(`pane-${targetTab}`);
            if (targetPane) targetPane.classList.add("active");

            // Chart resize adjustments
            if (targetTab === "statistics" && state.freqChart) {
                state.freqChart.resize();
            } else if (targetTab === "plsb") {
                if (state.cmpReallocChart) state.cmpReallocChart.resize();
                if (state.cmpCopyChart) state.cmpCopyChart.resize();
            }
        });
    });
}

// =========================================================================
// TAB 1: ANALYZER
// =========================================================================
function initAnalyzer() {
    const editor = document.getElementById("sourceCodeInput");
    const btnClear = document.getElementById("btnClearCode");
    const btnEx1 = document.getElementById("btnExample1");
    const btnEx2 = document.getElementById("btnExample2");
    const btnAnalyze = document.getElementById("btnAnalyzeCode");

    btnClear.addEventListener("click", () => {
        editor.value = "";
        state.currentSource = "";
        clearAnalyzerDisplay();
    });

    btnEx1.addEventListener("click", () => {
        editor.value = EXAMPLES.ex1;
        state.currentSource = EXAMPLES.ex1;
        analyzeSourceCode(EXAMPLES.ex1);
    });

    btnEx2.addEventListener("click", () => {
        editor.value = EXAMPLES.ex2;
        state.currentSource = EXAMPLES.ex2;
        analyzeSourceCode(EXAMPLES.ex2);
    });

    btnAnalyze.addEventListener("click", () => {
        const code = editor.value;
        state.currentSource = code;
        analyzeSourceCode(code);
    });

    // Token search & filters
    const searchInput = document.getElementById("tokenSearchInput");
    const filterType = document.getElementById("tokenFilterType");
    searchInput.addEventListener("input", renderTokenTable);
    filterType.addEventListener("change", renderTokenTable);

    // Export buttons
    document.getElementById("btnExportTokensCsv").addEventListener("click", exportTokensCsv);
    document.getElementById("btnExportTokensJson").addEventListener("click", exportTokensJson);
}

async function analyzeSourceCode(source) {
    if (!source || !source.trim()) {
        clearAnalyzerDisplay();
        return;
    }

    const statusBadge = document.getElementById("statusBadge");
    statusBadge.className = "badge badge-amber";
    statusBadge.textContent = "● Running Native C Lexer...";

    try {
        const resp = await fetch("/api/run", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                source: source,
                buffer_size: 32,
                baseline_cap: 16,
                rule: "max",
                mode: "compare"
            })
        });

        if (!resp.ok) {
            throw new Error(`HTTP ${resp.status}`);
        }

        const data = await resp.json();
        state.analysisResult = data;
        state.tokens = data.tokens_baseline || [];

        statusBadge.className = "badge badge-blue";
        statusBadge.textContent = "● Engine Ready";

        // Update Statistics & Tables
        computeAndRenderStatistics(source, state.tokens);
        renderTokenTable();

        // Update other dependent tabs
        resetBufferSimulationWithSource(source);
        updateTokenFrequencies();
        buildMarkovModelFromTokens();

    } catch (err) {
        console.error("Analysis failed:", err);
        statusBadge.className = "badge badge-rose";
        statusBadge.textContent = "✗ Analysis Error";
    }
}

function clearAnalyzerDisplay() {
    state.tokens = [];
    document.getElementById("kpiTotalTokens").textContent = "—";
    document.getElementById("kpiUniqueTokens").textContent = "—";
    document.getElementById("kpiKeywords").textContent = "—";
    document.getElementById("statChars").textContent = "0";
    document.getElementById("statLines").textContent = "0";
    document.getElementById("statTokens").textContent = "0";
    document.getElementById("statUnique").textContent = "0";
    document.getElementById("statKw").textContent = "0";
    document.getElementById("statId").textContent = "0";
    document.getElementById("statNum").textContent = "0";
    document.getElementById("statOp").textContent = "0";
    document.getElementById("statDelim").textContent = "0";
    document.getElementById("statCom").textContent = "0";
    document.getElementById("statErr").textContent = "0";
    document.getElementById("tokenTableCount").textContent = "0";
    document.getElementById("tokenTableBody").innerHTML = `
        <tr><td colspan="6" style="text-align: center; color: var(--text-dim); padding: 2rem;">No tokens analyzed yet. Enter code and click 'Analyze Code'.</td></tr>
    `;
}

function computeAndRenderStatistics(source, tokens) {
    const totalChars = source.length;
    const totalLines = source ? source.split("\n").length : 0;
    const totalTokens = tokens.length;

    const uniqueSet = new Set(tokens.map(t => t.lexeme));
    let kwCount = 0;
    let idCount = 0;
    let numCount = 0;
    let opCount = 0;
    let delimCount = 0;
    let comCount = 0;
    let errCount = 0;

    tokens.forEach(t => {
        const type = t.type.toUpperCase();
        if (type.startsWith("KW_") || C_KEYWORDS.has(t.lexeme)) {
            kwCount++;
        } else if (type === "IDENTIFIER") {
            idCount++;
        } else if (type.includes("INT") || type.includes("FLOAT") || type.includes("NUM")) {
            numCount++;
        } else if (type.startsWith("OP_")) {
            opCount++;
        } else if (type === "COMMENT") {
            comCount++;
        } else if (type.includes("ERR") || type.includes("UNKNOWN")) {
            errCount++;
        } else {
            delimCount++;
        }
    });

    document.getElementById("kpiTotalTokens").textContent = totalTokens;
    document.getElementById("kpiUniqueTokens").textContent = uniqueSet.size;
    document.getElementById("kpiKeywords").textContent = kwCount;

    document.getElementById("statChars").textContent = totalChars;
    document.getElementById("statLines").textContent = totalLines;
    document.getElementById("statTokens").textContent = totalTokens;
    document.getElementById("statUnique").textContent = uniqueSet.size;
    document.getElementById("statKw").textContent = kwCount;
    document.getElementById("statId").textContent = idCount;
    document.getElementById("statNum").textContent = numCount;
    document.getElementById("statOp").textContent = opCount;
    document.getElementById("statDelim").textContent = delimCount;
    document.getElementById("statCom").textContent = comCount;
    document.getElementById("statErr").textContent = errCount;
    document.getElementById("tokenTableCount").textContent = totalTokens;
}

function renderTokenTable() {
    const tbody = document.getElementById("tokenTableBody");
    const query = (document.getElementById("tokenSearchInput").value || "").toLowerCase().trim();
    const filter = document.getElementById("tokenFilterType").value;

    let filtered = state.tokens.filter(tok => {
        const matchQuery = !query || tok.lexeme.toLowerCase().includes(query) || tok.type.toLowerCase().includes(query);
        let matchFilter = true;
        if (filter !== "ALL") {
            const type = tok.type.toUpperCase();
            if (filter === "KEYWORD") matchFilter = type.startsWith("KW_") || C_KEYWORDS.has(tok.lexeme);
            else if (filter === "IDENTIFIER") matchFilter = type === "IDENTIFIER";
            else if (filter === "NUMBER") matchFilter = type.includes("INT") || type.includes("FLOAT");
            else if (filter === "STRING") matchFilter = type.includes("STR") || type.includes("CHAR");
            else if (filter === "OPERATOR") matchFilter = type.startsWith("OP_");
            else if (filter === "COMMENT") matchFilter = type === "COMMENT";
        }
        return matchQuery && matchFilter;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-dim); padding: 1.5rem;">No matching tokens found.</td></tr>`;
        return;
    }

    let rowsHtml = "";
    filtered.slice(0, 500).forEach((tok, idx) => {
        let badgeClass = "tok-delim";
        const type = tok.type.toUpperCase();
        if (type.startsWith("KW_") || C_KEYWORDS.has(tok.lexeme)) badgeClass = "tok-kw";
        else if (type === "IDENTIFIER") badgeClass = "tok-id";
        else if (type.includes("INT") || type.includes("FLOAT")) badgeClass = "tok-num";
        else if (type.includes("STR") || type.includes("CHAR")) badgeClass = "tok-str";
        else if (type.startsWith("OP_")) badgeClass = "tok-op";
        else if (type === "COMMENT") badgeClass = "tok-com";

        const spillPill = tok.spilled 
            ? `<span class="badge badge-amber" style="font-size: 0.68rem; padding: 0.1rem 0.4rem;">SPILLED</span>`
            : `<span style="color: var(--text-dim); font-size: 0.75rem;">Normal</span>`;

        rowsHtml += `
            <tr>
                <td style="font-family: var(--font-mono); color: var(--text-dim);">${idx + 1}</td>
                <td style="font-family: var(--font-mono); font-weight: 600; color: white;">${escapeHtml(tok.lexeme)}</td>
                <td><span class="tok-badge ${badgeClass}">${tok.type}</span></td>
                <td style="font-family: var(--font-mono); color: var(--text-muted); font-size: 0.8rem;">${tok.line}:${tok.col}</td>
                <td style="font-family: var(--font-mono); color: var(--text-muted); font-size: 0.8rem;">${tok.length}B</td>
                <td>${spillPill}</td>
            </tr>
        `;
    });

    tbody.innerHTML = rowsHtml;
}

function exportTokensCsv() {
    if (!state.tokens.length) return;
    const headers = ["ID", "Lexeme", "Type", "Line", "Column", "Length", "Spilled"];
    const rows = state.tokens.map((t, idx) => [
        idx + 1,
        `"${t.lexeme.replace(/"/g, '""')}"`,
        t.type,
        t.line,
        t.col,
        t.length,
        t.spilled ? 1 : 0
    ]);
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    downloadFile(csv, "plsb_tokens.csv", "text/csv");
}

function exportTokensJson() {
    if (!state.tokens.length) return;
    const json = JSON.stringify(state.tokens, null, 2);
    downloadFile(json, "plsb_tokens.json", "application/json");
}

// =========================================================================
// TAB 2: BUFFER VISUALIZATION
// =========================================================================
function initBufferSimulation() {
    document.getElementById("btnBufStart").addEventListener("click", () => {
        resetBufferSimulationWithSource(state.currentSource);
        state.bufferSimulation.isPlaying = true;
        updatePlayPauseButton();
        runSimulationLoop();
    });

    document.getElementById("btnBufPlayPause").addEventListener("click", () => {
        state.bufferSimulation.isPlaying = !state.bufferSimulation.isPlaying;
        updatePlayPauseButton();
        if (state.bufferSimulation.isPlaying) {
            runSimulationLoop();
        }
    });

    document.getElementById("btnBufNext").addEventListener("click", () => {
        state.bufferSimulation.isPlaying = false;
        updatePlayPauseButton();
        stepBufferSimulation();
    });

    document.getElementById("btnBufReset").addEventListener("click", () => {
        state.bufferSimulation.isPlaying = false;
        updatePlayPauseButton();
        resetBufferSimulationWithSource(state.currentSource);
    });
}

function updatePlayPauseButton() {
    const btn = document.getElementById("btnBufPlayPause");
    btn.innerHTML = state.bufferSimulation.isPlaying ? "⏸ Pause" : "▶ Play";
}

function resetBufferSimulationWithSource(source) {
    if (state.bufferSimulation.timer) {
        clearTimeout(state.bufferSimulation.timer);
        state.bufferSimulation.timer = null;
    }

    const B = state.bufferSimulation.bufferSize;
    const text = source || "";
    const b1 = text.slice(0, B).padEnd(B, "\0");
    const b2 = text.slice(B, B * 2).padEnd(B, "\0");

    state.bufferSimulation.buffer1 = b1;
    state.bufferSimulation.buffer2 = b2;
    state.bufferSimulation.activeBuffer = 1;
    state.bufferSimulation.charPointer = 0;
    state.bufferSimulation.forwardPointer = 0;
    state.bufferSimulation.currentChar = b1[0] !== "\0" ? b1[0] : "";
    state.bufferSimulation.currentLexeme = (b1[0] && b1[0] !== "\0" && !/\s/.test(b1[0])) ? b1[0] : "";
    state.bufferSimulation.refillCount = 0;
    state.bufferSimulation.spillCount = 0;
    state.bufferSimulation.isSpilled = false;
    state.bufferSimulation.position = 0;

    renderBufferBlocks();
    updateBufferMetrics();
}

function runSimulationLoop() {
    if (!state.bufferSimulation.isPlaying) return;
    stepBufferSimulation();

    const maxPos = state.currentSource ? state.currentSource.length : 0;
    if (state.bufferSimulation.position < maxPos - 1) {
        state.bufferSimulation.timer = setTimeout(runSimulationLoop, 120);
    } else {
        state.bufferSimulation.isPlaying = false;
        updatePlayPauseButton();
    }
}

function stepBufferSimulation() {
    const sim = state.bufferSimulation;
    const src = state.currentSource || "";
    if (sim.position >= src.length - 1) return;

    sim.position += 1;
    sim.forwardPointer += 1;

    const B = sim.bufferSize;
    let justSpilled = false;

    if (sim.forwardPointer >= B) {
        sim.refillCount += 1;
        sim.forwardPointer = 0;
        sim.charPointer = 0;

        // Lexeme crossing buffer boundary triggers spill
        if (sim.currentLexeme.length > 0) {
            sim.isSpilled = true;
            sim.spillCount += 1;
            justSpilled = true;
        }

        if (sim.activeBuffer === 1) {
            const start = (sim.refillCount + 1) * B;
            sim.buffer1 = src.slice(start, start + B).padEnd(B, "\0");
            sim.activeBuffer = 2;
        } else {
            const start = (sim.refillCount + 1) * B;
            sim.buffer2 = src.slice(start, start + B).padEnd(B, "\0");
            sim.activeBuffer = 1;
        }
    } else {
        sim.charPointer = sim.forwardPointer;
    }

    const curBuf = sim.activeBuffer === 1 ? sim.buffer1 : sim.buffer2;
    const ch = curBuf[sim.charPointer] || "";
    sim.currentChar = ch === "\0" ? "" : ch;

    if (sim.currentChar && !/\s/.test(sim.currentChar) && !/[,;(){}[\]]/.test(sim.currentChar)) {
        sim.currentLexeme += sim.currentChar;
    } else if (sim.currentChar && /\s/.test(sim.currentChar)) {
        sim.currentLexeme = "";
        sim.isSpilled = false;
    } else if (sim.currentChar) {
        sim.currentLexeme = sim.currentChar;
        if (!justSpilled) sim.isSpilled = false;
    }

    renderBufferBlocks();
    updateBufferMetrics();
}

function renderBufferBlocks() {
    const sim = state.bufferSimulation;
    const b1Container = document.getElementById("bufCells1");
    const b2Container = document.getElementById("bufCells2");

    function renderCells(bufStr, isActive) {
        let html = "";
        for (let i = 0; i < bufStr.length; i++) {
            const ch = bufStr[i];
            const display = ch === "\0" ? "·" : (ch === " " ? "␣" : escapeHtml(ch));
            let cls = "buf-char";
            if (isActive && i === sim.charPointer) {
                cls += " char-ptr";
            } else if (isActive && i === sim.forwardPointer) {
                cls += " fwd-ptr";
            }
            html += `<span class="${cls}">${display}</span>`;
        }
        return html;
    }

    b1Container.innerHTML = renderCells(sim.buffer1, sim.activeBuffer === 1);
    b2Container.innerHTML = renderCells(sim.buffer2, sim.activeBuffer === 2);

    const b1Box = document.getElementById("bufBox1");
    const b2Box = document.getElementById("bufBox2");
    const b1Tag = document.getElementById("bufTag1");
    const b2Tag = document.getElementById("bufTag2");

    if (sim.activeBuffer === 1) {
        b1Box.className = "buffer-box active";
        b2Box.className = "buffer-box";
        b1Tag.style.display = "inline-flex";
        b2Tag.style.display = "none";
    } else {
        b1Box.className = "buffer-box";
        b2Box.className = "buffer-box active";
        b1Tag.style.display = "none";
        b2Tag.style.display = "inline-flex";
    }
}

function updateBufferMetrics() {
    const sim = state.bufferSimulation;
    const src = state.currentSource || "";

    document.getElementById("bufMetricActive").textContent = `Buffer ${sim.activeBuffer}`;
    document.getElementById("bufMetricCharPtr").textContent = sim.charPointer;
    document.getElementById("bufMetricFwdPtr").textContent = sim.forwardPointer;
    document.getElementById("bufMetricChar").textContent = sim.currentChar || "—";
    document.getElementById("bufMetricLexeme").textContent = sim.currentLexeme || "—";
    document.getElementById("bufMetricRefills").textContent = sim.refillCount;
    document.getElementById("bufMetricSpills").textContent = sim.spillCount;
    document.getElementById("bufMetricSpillState").textContent = sim.isSpilled ? "ACTIVE (ACCUMULATING)" : "IDLE";
    document.getElementById("bufMetricSpillState").style.color = sim.isSpilled ? "#fbbf24" : "#94a3b8";

    const pct = src.length > 0 ? Math.round(((sim.position + 1) / src.length) * 100) : 0;
    document.getElementById("bufProgressBar").style.width = `${pct}%`;
    document.getElementById("bufProgressText").textContent = `Character ${sim.position + 1} of ${src.length} (${pct}%)`;
}

// =========================================================================
// TAB 3: TOKEN STATISTICS
// =========================================================================
function initTokenStats() {
    const btnType = document.getElementById("btnFreqModeType");
    const btnLexeme = document.getElementById("btnFreqModeLexeme");

    btnType.addEventListener("click", () => {
        state.freqMode = "type";
        btnType.className = "btn-primary";
        btnLexeme.className = "btn-secondary";
        updateTokenFrequencies();
    });

    btnLexeme.addEventListener("click", () => {
        state.freqMode = "lexeme";
        btnLexeme.className = "btn-primary";
        btnType.className = "btn-secondary";
        updateTokenFrequencies();
    });
}

function updateTokenFrequencies() {
    if (!state.tokens.length) {
        document.getElementById("freqMostFrequentVal").textContent = "—";
        document.getElementById("freqTableBody").innerHTML = `
            <tr><td colspan="4" style="text-align: center; color: var(--text-dim); padding: 2rem;">Analyze code to display frequency metrics.</td></tr>
        `;
        return;
    }

    const counts = {};
    state.tokens.forEach(t => {
        const key = state.freqMode === "type" ? t.type : t.lexeme;
        counts[key] = (counts[key] || 0) + 1;
    });

    const total = state.tokens.length;
    const sorted = Object.entries(counts).map(([label, count]) => ({
        label,
        count,
        percentage: ((count / total) * 100).toFixed(1)
    })).sort((a, b) => b.count - a.count);

    document.getElementById("freqMostFrequentVal").textContent = `${sorted[0].label} (${sorted[0].count})`;

    // Render Table
    let tableHtml = "";
    sorted.forEach(item => {
        tableHtml += `
            <tr>
                <td style="font-family: var(--font-mono); font-weight: 600; color: white;">${escapeHtml(item.label)}</td>
                <td style="font-family: var(--font-mono);">${item.count}</td>
                <td style="font-family: var(--font-mono); color: var(--text-muted);">${item.percentage}%</td>
                <td style="width: 35%;">
                    <div style="height: 6px; border-radius: 9999px; background: rgba(51, 65, 85, 0.5); overflow: hidden;">
                        <div style="height: 100%; width: ${item.percentage}%; background: ${state.freqMode === "type" ? "#3b82f6" : "#a855f7"};"></div>
                    </div>
                </td>
            </tr>
        `;
    });
    document.getElementById("freqTableBody").innerHTML = tableHtml;

    // Render Chart.js
    const ctx = document.getElementById("freqChartCanvas").getContext("2d");
    const top12 = sorted.slice(0, 12);

    if (state.freqChart) {
        state.freqChart.destroy();
    }

    state.freqChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: top12.map(d => d.label),
            datasets: [{
                label: state.freqMode === "type" ? "Token Type Count" : "Lexeme Count",
                data: top12.map(d => d.count),
                backgroundColor: state.freqMode === "type" ? "rgba(59, 130, 246, 0.75)" : "rgba(168, 85, 247, 0.75)",
                borderColor: state.freqMode === "type" ? "#3b82f6" : "#a855f7",
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: "#94a3b8" } },
                tooltip: {
                    callbacks: {
                        afterLabel: (ctx) => `Share: ${top12[ctx.dataIndex].percentage}%`
                    }
                }
            },
            scales: {
                x: {
                    grid: { color: "rgba(51, 65, 85, 0.4)" },
                    ticks: { color: "#94a3b8", font: { family: "'JetBrains Mono', monospace" } }
                },
                y: {
                    grid: { color: "rgba(51, 65, 85, 0.4)" },
                    ticks: { color: "#94a3b8" },
                    title: { display: true, text: "Count", color: "#94a3b8" }
                }
            }
        }
    });
}

// =========================================================================
// TAB 4: MARKOV PREDICTION
// =========================================================================
function initMarkov() {
    const select = document.getElementById("selectMarkovToken");
    select.addEventListener("change", (e) => {
        state.markovSelectedToken = e.target.value;
        renderMarkovPredictions();
    });
}

function buildMarkovModelFromTokens() {
    const tokens = state.tokens.filter(t => t.type !== "COMMENT");
    if (tokens.length < 2) {
        document.getElementById("markovTableBody").innerHTML = `
            <tr><td colspan="4" style="text-align: center; color: var(--text-dim); padding: 1.5rem;">Insufficient tokens to construct Markov model.</td></tr>
        `;
        return;
    }

    const transitions = {};
    for (let i = 0; i < tokens.length - 1; i++) {
        const cur = tokens[i].type;
        const next = tokens[i + 1].type;
        if (!transitions[cur]) transitions[cur] = {};
        transitions[cur][next] = (transitions[cur][next] || 0) + 1;
    }

    const transitionList = [];
    const uniqueTokens = Object.keys(transitions).sort();

    uniqueTokens.forEach(cur => {
        const nextMap = transitions[cur];
        const total = Object.values(nextMap).reduce((a, b) => a + b, 0);
        Object.entries(nextMap).forEach(([next, count]) => {
            transitionList.push({
                cur,
                next,
                count,
                prob: count / total
            });
        });
    });

    state.markovTransitions = transitionList;

    // Populate dropdown
    const select = document.getElementById("selectMarkovToken");
    select.innerHTML = uniqueTokens.map(tok => `<option value="${tok}">${tok}</option>`).join("");
    if (uniqueTokens.length) {
        state.markovSelectedToken = uniqueTokens[0];
        select.value = uniqueTokens[0];
    }

    renderMarkovPredictions();
    renderMarkovTable();
    renderMarkovGraphSvg(uniqueTokens.slice(0, 8));
}

function renderMarkovPredictions() {
    const cur = state.markovSelectedToken;
    document.getElementById("markovCurrentCard").textContent = cur || "—";

    const matches = state.markovTransitions
        .filter(t => t.cur === cur)
        .sort((a, b) => b.prob - a.prob);

    if (matches.length > 0) {
        const top = matches[0];
        document.getElementById("markovPredictedCard").textContent = top.next;
        document.getElementById("markovProbCard").textContent = `${(top.prob * 100).toFixed(1)}% probability`;

        // Top 3 Pills
        const pillsHtml = matches.slice(0, 3).map(m => `
            <div style="background: rgba(30, 41, 59, 0.7); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 0.5rem 0.85rem; font-family: var(--font-mono); font-size: 0.8rem;">
                <span style="color: white; font-weight: 600;">${m.next}</span>
                <span style="color: #c084fc; margin-left: 0.4rem;">${(m.prob * 100).toFixed(1)}%</span>
            </div>
        `).join("");
        document.getElementById("markovTopPills").innerHTML = pillsHtml;
    } else {
        document.getElementById("markovPredictedCard").textContent = "—";
        document.getElementById("markovProbCard").textContent = "0.0% probability";
        document.getElementById("markovTopPills").innerHTML = `<span style="color: var(--text-dim); font-size: 0.8rem;">No transitions recorded.</span>`;
    }
}

function renderMarkovTable() {
    const tbody = document.getElementById("markovTableBody");
    const sorted = [...state.markovTransitions].sort((a, b) => b.count - a.count);

    if (!sorted.length) return;

    let html = "";
    sorted.slice(0, 100).forEach(t => {
        html += `
            <tr>
                <td style="font-family: var(--font-mono); color: #93c5fd; font-weight: 600;">${t.cur}</td>
                <td style="font-family: var(--font-mono); color: #c084fc; font-weight: 600;">${t.next}</td>
                <td style="font-family: var(--font-mono);">${t.count}</td>
                <td style="font-family: var(--font-mono); color: #34d399;">${(t.prob * 100).toFixed(1)}%</td>
            </tr>
        `;
    });
    tbody.innerHTML = html;
}

function renderMarkovGraphSvg(nodes) {
    const svg = document.getElementById("markovSvgGraph");
    if (!nodes.length) {
        svg.innerHTML = "";
        return;
    }

    const width = 560;
    const height = 320;
    const cx = width / 2;
    const cy = height / 2;
    const radius = 110;

    const angleStep = (2 * Math.PI) / nodes.length;
    const coords = {};

    let elementsSvg = "";

    // Nodes
    nodes.forEach((name, i) => {
        const angle = i * angleStep;
        const x = cx + radius * Math.cos(angle);
        const y = cy + radius * Math.sin(angle);
        coords[name] = { x, y };
    });

    // Edges
    state.markovTransitions.forEach(t => {
        if (coords[t.cur] && coords[t.next] && t.cur !== t.next) {
            const p1 = coords[t.cur];
            const p2 = coords[t.next];
            const strokeWidth = Math.max(1, Math.min(4, t.prob * 5));
            elementsSvg += `
                <line x1="${p1.x}" y1="${p1.y}" x2="${p2.x}" y2="${p2.y}" 
                      stroke="rgba(168, 85, 247, 0.4)" stroke-width="${strokeWidth}" />
            `;
        }
    });

    // Node circles & labels
    nodes.forEach(name => {
        const p = coords[name];
        elementsSvg += `
            <circle cx="${p.x}" cy="${p.y}" r="22" fill="#1e293b" stroke="#3b82f6" stroke-width="2" />
            <text x="${p.x}" y="${p.y + 4}" fill="#f8fafc" font-size="9" font-family="'JetBrains Mono', monospace" text-anchor="middle" font-weight="bold">${name.slice(0, 4)}</text>
        `;
    });

    svg.innerHTML = elementsSvg;
}

// =========================================================================
// TAB 5: PLSB COMPARISON
// =========================================================================
function initComparison() {
    document.getElementById("btnRunComparison").addEventListener("click", runComparison);
    document.getElementById("btnExportCmpCsv").addEventListener("click", exportComparisonCsv);
}

let latestComparisonResults = null;

async function runComparison() {
    const datasetChoice = document.getElementById("selectCmpDataset").value;
    const bufferSize = parseInt(document.getElementById("selectCmpBufferSize").value, 10);
    const btn = document.getElementById("btnRunComparison");
    btn.disabled = true;
    btn.textContent = "Running Native C Engine...";

    const payload = {
        buffer_size: bufferSize,
        policies: ["baseline_16", "baseline_32", "baseline_64", "p75", "ewma", "max", "weighted", "markov"]
    };

    if (datasetChoice === "CURRENT") {
        payload.source = state.currentSource;
    } else {
        payload.dataset = datasetChoice;
    }

    try {
        const resp = await fetch("/api/compare", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

        const data = await resp.json();
        latestComparisonResults = data;
        renderComparisonResults(data);
    } catch (err) {
        alert("Comparison execution error: " + err.message);
    } finally {
        btn.disabled = false;
        btn.textContent = "▶ Run Live Comparison";
    }
}

function renderComparisonResults(data) {
    const tbody = document.getElementById("cmpTableBody");
    const runs = data.runs || [];

    if (!runs.length) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align: center; color: var(--text-dim); padding: 2rem;">No comparison runs returned.</td></tr>`;
        return;
    }

    let rowsHtml = "";
    runs.forEach(r => {
        const isBase = r.category === "baseline";
        const reallocDelta = r.realloc_delta_pct ?? 0;
        const copyDelta = r.copy_delta_pct ?? 0;

        const reallocDeltaBadge = isBase && r.config_id === "baseline_16"
            ? `<span style="color: var(--text-dim);">Reference (0%)</span>`
            : reallocDelta < 0
                ? `<span style="color: #34d399; font-weight: 600;">↓ ${Math.abs(reallocDelta)}%</span>`
                : reallocDelta > 0
                    ? `<span style="color: #f87171;">↑ +${reallocDelta}%</span>`
                    : `<span style="color: var(--text-dim);">0.0%</span>`;

        const copyDeltaBadge = isBase && r.config_id === "baseline_16"
            ? `<span style="color: var(--text-dim);">Reference (0%)</span>`
            : copyDelta < 0
                ? `<span style="color: #34d399; font-weight: 600;">↓ ${Math.abs(copyDelta)}%</span>`
                : copyDelta > 0
                    ? `<span style="color: #f87171;">↑ +${copyDelta}%</span>`
                    : `<span style="color: var(--text-dim);">0.0%</span>`;

        rowsHtml += `
            <tr style="${!isBase ? 'background: rgba(59, 130, 246, 0.04);' : ''}">
                <td style="font-weight: 600; color: white;">
                    <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: ${isBase ? '#fbbf24' : '#3b82f6'}; margin-right: 6px;"></span>
                    ${r.display_label}
                </td>
                <td style="font-family: var(--font-mono);">${r.total_tokens}</td>
                <td style="font-family: var(--font-mono);">${r.lexeme_spill_events}</td>
                <td style="font-family: var(--font-mono); font-weight: 700; color: white;">${r.spill_reallocations}</td>
                <td style="font-family: var(--font-mono);">${reallocDeltaBadge}</td>
                <td style="font-family: var(--font-mono); font-weight: 700; color: white;">${r.growth_copy_bytes} B</td>
                <td style="font-family: var(--font-mono);">${copyDeltaBadge}</td>
                <td style="font-family: var(--font-mono);">${r.peak_spill_capacity} B</td>
                <td style="font-family: var(--font-mono); color: #94a3b8;">${Math.round(r.tokens_per_second / 1000)} kTok/s</td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    // Render Dual Comparison Charts
    renderComparisonCharts(runs);
}

function renderComparisonCharts(runs) {
    const labels = runs.map(r => r.display_label.replace("Baseline ", "Base ").replace("PLSB ", ""));
    const reallocs = runs.map(r => r.spill_reallocations);
    const copies = runs.map(r => r.growth_copy_bytes);

    // 1. Reallocations Chart
    const ctx1 = document.getElementById("cmpReallocChartCanvas").getContext("2d");
    if (state.cmpReallocChart) state.cmpReallocChart.destroy();
    state.cmpReallocChart = new Chart(ctx1, {
        type: "bar",
        data: {
            labels,
            datasets: [{
                label: "Spill Reallocations",
                data: reallocs,
                backgroundColor: runs.map(r => r.category === "baseline" ? "rgba(245, 158, 11, 0.75)" : "rgba(59, 130, 246, 0.75)"),
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: "#94a3b8", font: { size: 10 } } },
                y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" } }
            }
        }
    });

    // 2. Growth Copy Bytes Chart
    const ctx2 = document.getElementById("cmpCopyChartCanvas").getContext("2d");
    if (state.cmpCopyChart) state.cmpCopyChart.destroy();
    state.cmpCopyChart = new Chart(ctx2, {
        type: "bar",
        data: {
            labels,
            datasets: [{
                label: "Copy Overhead (Bytes)",
                data: copies,
                backgroundColor: runs.map(r => r.category === "baseline" ? "rgba(245, 158, 11, 0.75)" : "rgba(168, 85, 247, 0.75)"),
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: "#94a3b8", font: { size: 10 } } },
                y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" } }
            }
        }
    });
}

function exportComparisonCsv() {
    if (!latestComparisonResults || !latestComparisonResults.runs) return;
    const headers = ["Configuration", "Category", "Tokens", "Boundary Spills", "Reallocations", "Realloc Delta %", "Copy Bytes", "Copy Delta %", "Peak Capacity", "Throughput tok/s"];
    const rows = latestComparisonResults.runs.map(r => [
        `"${r.display_label}"`,
        r.category,
        r.total_tokens,
        r.lexeme_spill_events,
        r.spill_reallocations,
        r.realloc_delta_pct ?? 0,
        r.growth_copy_bytes,
        r.copy_delta_pct ?? 0,
        r.peak_spill_capacity,
        r.tokens_per_second.toFixed(2)
    ]);
    const csv = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    downloadFile(csv, `plsb_comparison_${latestComparisonResults.buffer_size}B.csv`, "text/csv");
}

// =========================================================================
// TEST SUITE PRESERVATION / BACKWARD COMPATIBILITY
// =========================================================================
/**
 * Preserves the renderReallocsChart symbol required by scripts/test_dashboard_endpoints.py
 */
function renderReallocsChart(ctx, results) {
    if (!ctx) return;
    return new Chart(ctx, {
        type: 'bar',
        data: { labels: ['Verified Matrix'], datasets: [{ data: [12, 19] }] },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

// Utility Helpers
function escapeHtml(str) {
    return (str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function downloadFile(content, fileName, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}
